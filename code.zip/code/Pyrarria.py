###########
# No Name #
###########

import pygame
from player import Player
Player(0, 0)
