class Person:
    def __init__(pog,name,age):
        pog.name = name
        pog.age = age

    def funcName(picklePants):
        print("Ooga booga go to the shooga, " + picklePants.name)

var = Person("Jonald",34.892783649238765492387654923790756)
var.age = 35
var.funcName()
print(var.age)
del var

class Purpleson:
    def __init__(self,fname,lname):
        self.firstname = fname
        self.lastname = lname

    def printName(self):
        print(self.firstname,self.lastname)

x = Purpleson("Jonald", "Poggersworth")
x.printName()

class Student(Purpleson):
    def __init__(self,fname,lname,year):
        super().__init__(fname,lname)
        self.graduationYear = year

    def welcome(self):
        print("Welcome", self.firstname, self.lastname, "to the class of", self.graduationYear)



x = Student("Poggers", "Jonaldson", 2019)
x.printName()
x.welcome()
